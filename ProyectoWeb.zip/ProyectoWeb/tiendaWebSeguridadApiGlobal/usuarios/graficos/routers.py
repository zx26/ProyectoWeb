#modulo donde se alamacenaran los router
import rest_framework


from rest_framework import routers
from rest_framework.routers import DefaultRouter
from usuarios.graficos.vistas.views import VistaUsuario

router=DefaultRouter()
router.register(r'usuario',VistaUsuario, basename='usuario')

urlpatterns= router.urls

