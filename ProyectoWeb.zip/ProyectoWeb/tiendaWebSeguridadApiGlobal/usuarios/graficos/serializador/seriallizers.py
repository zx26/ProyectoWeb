#Modulo donde estaran almacenados los serializadores
from rest_framework import serializers
from usuarios.models import RegistroUsuarios

class SerializadorBase(serializers.ModelSerializer):
    class Meta:
        model=RegistroUsuarios
        fields='__all__'
