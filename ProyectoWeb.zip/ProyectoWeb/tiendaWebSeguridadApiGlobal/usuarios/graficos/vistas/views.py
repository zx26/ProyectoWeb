from django.db.models import query
from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.response import Response
from usuarios.graficos.serializador.seriallizers import SerializadorBase

# Create your views here.
class VistaBase(viewsets.ModelViewSet):
    serializer_class=None

    def get_queryset(self):
        model= self.get_serializer().Meta.model
        return model.objects.filter()

class VistaUsuario(VistaBase):
    serializer_class= SerializadorBase
    queryset=  SerializadorBase.Meta.model.objects.filter()

   



