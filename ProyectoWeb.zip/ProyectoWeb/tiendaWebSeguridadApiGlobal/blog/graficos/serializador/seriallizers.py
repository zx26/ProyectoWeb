#Modulo donde estaran almacenados los serializadores
from rest_framework import serializers
from blog.models import Entrada

class SerializadorBaseBlog(serializers.ModelSerializer):
    class Meta:
        model=Entrada
        fields='__all__'
