#modulo donde se alamacenaran los router
import rest_framework


from rest_framework import routers
from rest_framework.routers import DefaultRouter
from blog.graficos.vistas.views import VistaBlog

router=DefaultRouter()
router.register(r'blogs',VistaBlog, basename='blogs')

urlpatterns= router.urls

