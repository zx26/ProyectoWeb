from django.db import models

# Create your models here.
class ModeloBase(models.Model):
    id=models.AutoField(primary_key=True)
    titulo=models.TextField(max_length=50)
    fecha=models.DateField('fecha', auto_now=True, auto_now_add=False)

    class Meta:
        abstract=True

class Carro(ModeloBase):
    cantidad=models.IntegerField()
