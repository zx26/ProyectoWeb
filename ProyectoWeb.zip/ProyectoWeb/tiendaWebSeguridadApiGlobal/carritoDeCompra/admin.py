from django.contrib import admin

from usuarios.models import RegistroUsuarios

# Register your models here.

admin.site.register(RegistroUsuarios)
