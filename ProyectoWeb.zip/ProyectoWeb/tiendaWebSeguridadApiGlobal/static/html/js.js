class DatosAPI
{
  constructor(){

    this._xhttp = new XMLHttpRequest();
  }
  respuesta() {
        return this._xhttp;
    }
  datosAsincronos()
  {
    this._xhttp.open("GET", "http://localhost:8000/usuario/usuario/info", true);
    this._xhttp.setRequestHeader("Content-type", "application/json");
  	this._xhttp.send(null);
   
  }
}

let api = new DatosAPI();

api.datosAsincronos();
   
api.respuesta().onreadystatechange = function() {

  if (api.respuesta().readyState == 4 && api.respuesta().status == 200) {
  
    console.log(JSON.parse(api.respuesta().responseText));

  }
};