#modulo donde se alamacenaran los router
from django.urls.conf import include, path
import rest_framework







urlpatterns= [
    path('compra/',include('apps.carritoDeCompra.api.routers')),
]

