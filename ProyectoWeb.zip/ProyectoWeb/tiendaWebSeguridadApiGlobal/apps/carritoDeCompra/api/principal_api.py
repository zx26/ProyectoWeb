from apps.carritoDeCompra.api.compras_api import ApiInfoCompra

class ApiViewGeneral(object):

    def __init__(self) -> None:
        super().__init__()
        self.viewset= [ApiInfoCompra(),]


    def get_view_set(self):
        return self.viewset    