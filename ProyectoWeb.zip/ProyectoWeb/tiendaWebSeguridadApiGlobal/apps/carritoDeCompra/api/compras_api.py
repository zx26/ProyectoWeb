from django.shortcuts import render
from apps.carritoDeCompra.api.base.base_api import VistaBase 
from apps.carritoDeCompra.api.serializers.registro_serializers import SerializadorBase, SerializadorBaseBlog



class ApiInfoCompra(VistaBase):
    """Resumen
    

    Clase que servira como vista principal de las apis 
    del modelo compras"""
    serializer_class= SerializadorBase



    def __str__(self):
        return r"compras"

 


      

   



