#Modulo donde estaran almacenados los serializadores
from rest_framework.serializers import ModelSerializer
from apps.carritoDeCompra.models.compras_models import CestaProducto


class SerializadorBase(ModelSerializer):
    """Resumen
    

    Clase que se usara en para serializar el modelo de compras"""
    class Meta:
        model=CestaProducto
        fields='__all__'


        
