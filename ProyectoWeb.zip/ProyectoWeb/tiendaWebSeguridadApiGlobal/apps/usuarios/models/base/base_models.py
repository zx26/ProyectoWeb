from django.db.models import Model, AutoField, DateField

class ModeloBase(Model):
    id=AutoField(primary_key=True)
    fecha=DateField('fecha', auto_now=True, auto_now_add=False)

    class Meta:
        abstract=True