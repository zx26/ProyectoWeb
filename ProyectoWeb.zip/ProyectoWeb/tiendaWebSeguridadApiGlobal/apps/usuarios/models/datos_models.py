from django.db.models import CharField, TextField,EmailField
from apps.usuarios.models.base.base_models import ModeloBase

# Create your models here.


class InfoUsuario(ModeloBase):
    nombre_usuario=CharField(max_length=60)
    direccion=TextField()
    correo= EmailField()
