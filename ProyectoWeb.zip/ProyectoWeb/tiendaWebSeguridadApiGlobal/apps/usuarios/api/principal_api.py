from apps.usuarios.api.datos_api import ApiInfoUsuario

class ApiViewGeneral(object):

    def __init__(self) -> None:
        super().__init__()
        self.viewset= [ApiInfoUsuario(),]


    def get_view_set(self):
        return self.viewset    