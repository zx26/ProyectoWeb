from abc import abstractmethod
from rest_framework.viewsets import ModelViewSet


class VistaBase(ModelViewSet):
    """Resumen  
    

    
    Clase padre de las vistas api view, cuya finalidad es servir
    de herencia para las demas que esten en el proyecto"""

    serializer_class=None #variable de la clase del serializador declarada none por su uso abstracto
    

    filterset_fields = '__all__'

    search_fields = ['name']

    ordering_fields = '__all__'

    def get_queryset(self):
        """Metodo que designara y retornara el query sin 
        tener que tocar nada en las demas clases"""
        
        model= self.get_serializer().Meta.model
        queryset=model.objects.filter()
        return queryset     


    @classmethod
    def get_view_set(self):
        return self

    @abstractmethod
    def __str__(self):
        pass        


