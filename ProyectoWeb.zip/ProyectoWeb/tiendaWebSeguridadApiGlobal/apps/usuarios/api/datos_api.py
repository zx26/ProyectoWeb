from django.shortcuts import render
from apps.usuarios.api.base.base_api import VistaBase 
from apps.usuarios.api.serializers.registro_serializers import SerializadorBase



class ApiInfoUsuario(VistaBase):
    """Resumen
    

    Clase que servira como vista principal de las apis 
    del modelo usuario"""
    serializer_class= SerializadorBase



    def __str__(self):
        return r"info"

 


      

   



