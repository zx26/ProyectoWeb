#Modulo donde estaran almacenados los serializadores
from rest_framework.serializers import ModelSerializer

from apps.usuarios.models.datos_models import InfoUsuario


class SerializadorBase(ModelSerializer):
    """Resumen
    

    Clase que se usara en para serializar el modelo de usuarios"""
    class Meta:
        model=InfoUsuario
        fields='__all__'



