from django.contrib import admin
from apps.usuarios.models.datos_models import InfoUsuario
# Register your models here.

admin.site.register(InfoUsuario)