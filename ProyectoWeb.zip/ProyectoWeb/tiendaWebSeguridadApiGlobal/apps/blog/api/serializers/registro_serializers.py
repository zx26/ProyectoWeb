#Modulo donde estaran almacenados los serializadores
from rest_framework.serializers import ModelSerializer
from apps.blog.models.publicacion_models import Entrada



class SerializadorBaseBlog(ModelSerializer):
    """Resumen
    

    Clase que se usara en para serializar el modelo blog"""
    class Meta:
        model=Entrada
        fields='__all__'        
