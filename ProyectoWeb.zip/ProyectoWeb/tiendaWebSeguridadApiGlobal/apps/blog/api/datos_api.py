from django.shortcuts import render
from apps.usuarios.api.base.base_api import VistaBase 
from apps.usuarios.api.serializers.registro_serializers import SerializadorBase, SerializadorBaseBlog





 

class ApiBlog(VistaBase):
    """Resumen
    

    Clase que servira como vista principal de las apis 
    del modelo blog"""

    serializer_class= SerializadorBaseBlog

    
    def __string__():
        return r'blog'
      

   



