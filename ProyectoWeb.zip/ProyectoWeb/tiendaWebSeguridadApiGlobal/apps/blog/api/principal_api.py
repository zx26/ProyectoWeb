from apps.blog.api.datos_api import ApiBlog

class ApiViewGeneral(object):

    def __init__(self) -> None:
        super().__init__()
        self.viewset= [ApiBlog(),]


    def get_view_set(self):
        return self.viewset    