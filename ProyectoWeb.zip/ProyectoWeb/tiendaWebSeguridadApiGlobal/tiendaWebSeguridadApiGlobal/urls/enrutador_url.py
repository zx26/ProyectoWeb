#modulo donde se alamacenaran los router
import rest_framework


from rest_framework import routers
from rest_framework.routers import DefaultRouter
from tiendaWebSeguridadApiGlobal.api_views.api_vistas_modelos import VistaUsuario, VistaBlog

router=DefaultRouter()
router.register(r'usuario',VistaUsuario, basename='usuario')
router.register(r'blogs',VistaBlog, basename='blogs')


urlpatterns= router.urls

