from django.shortcuts import render
from tiendaWebSeguridadApiGlobal.api_views.base.api_vista_base import VistaBase 
from tiendaWebSeguridadApiGlobal.api_views.serializador.seriallizador_modelos import SerializadorBase, SerializadorBaseBlog



class VistaUsuario(VistaBase):
    """Resumen
    

    Clase que servira como vista principal de las apis 
    del modelo usuario"""
    serializer_class= SerializadorBase

 

class VistaBlog(VistaBase):
    """Resumen
    

    Clase que servira como vista principal de las apis 
    del modelo blog"""

    serializer_class= SerializadorBaseBlog
      

   



