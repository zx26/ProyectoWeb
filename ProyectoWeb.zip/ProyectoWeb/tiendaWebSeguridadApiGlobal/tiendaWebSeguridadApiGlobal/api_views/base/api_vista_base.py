from rest_framework.viewsets import ModelViewSet


class VistaBase(ModelViewSet):
    """Resumen  
    

    
    Clase padre de las vistas api view, cuya finalidad es servir
    de herencia para las demas que esten en el proyecto"""

    serializer_class=None #variable de la clase del serializador declarada none por su uso abstracto


    def get_queryset(self):
        """Metodo que designara y retornara el query sin 
        tener que tocar nada en las demas clases"""
        
        model= self.get_serializer().Meta.model
        queryset=model.objects.filter()
        return queryset 